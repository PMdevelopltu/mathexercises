﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matematikos_uzduotius
{
    public partial class MainMenu : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
       (
           int nLeftRect,     // x-coordinate of upper-left corner
           int nTopRect,      // y-coordinate of upper-left corner
           int nRightRect,    // x-coordinate of lower-right corner
           int nBottomRect,   // y-coordinate of lower-right corner
           int nWidthEllipse, // width of ellipse
           int nHeightEllipse // height of ellipse
       );

        public MainMenu()
        {
            InitializeComponent();
           /* this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));*/
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form about = new AboutBox1();
            about.Show();
        }

        private void easyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form lengvas = new Form1();
            lengvas.Show();
        }

        private void mediumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form theOtherOne = new Form2();
            theOtherOne.Name = "Vidutinis lygis";
            theOtherOne.Show();
        }

        private void hardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form theOtherOne = new Form3();
            theOtherOne.Name = "Sunkus lygis";
            theOtherOne.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form lengvas = new Form1();
            lengvas.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form theOtherOne = new Form2();
            theOtherOne.Name = "Vidutinis lygis";
            theOtherOne.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form theOtherOne = new Form3();
            theOtherOne.Name = "Sunkus lygis";
            theOtherOne.Show();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
